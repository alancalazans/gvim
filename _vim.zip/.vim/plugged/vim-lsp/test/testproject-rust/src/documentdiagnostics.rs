fn document_diagnostics() {
    unimplemented!();
}

fn broken1(
    print
}

fn broken2()
    broken(1);
}
